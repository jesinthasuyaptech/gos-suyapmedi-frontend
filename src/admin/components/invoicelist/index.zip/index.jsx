import React, { useState, useEffect } from "react";
import SidebarNav from "../sidebar";
import { Table, Button, Modal, Form, Input, Radio, Select, DatePicker, notification } from "antd";
import { itemRender, onShowSizeChange } from "../paginationfunction";
import { Link } from "react-router-dom";
import moment from "moment"; // For handling date format
import { useLocation } from "react-router-dom";
import { var_api } from "../../../constant";
import { Checkbox } from "antd";
import axios from "axios";

const InvoiceList = () => {
  const [data, setData] = useState([]);
  const [filteredData, setFilteredData] = useState([]); // Filtered data for the table
  const [loading, setLoading] = useState(false);
  const [searchTerm, setSearchTerm] = useState("");
  const [currentPage, setCurrentPage] = useState(1);
  const [pageSize, setPageSize] = useState(10); 
  const hospital_id = localStorage.getItem("hospital_id");
  const [isModalVisible, setIsModalVisible] = useState(false);
  const [currentBillingId, setCurrentBillingId] = useState(null);
  const [selectedPaymentModes, setSelectedPaymentModes] = useState([]);


  const showModal = (billingId) => {
    setCurrentBillingId(billingId);
    setIsModalVisible(true);
  };


  const fetchData = async () => {
    const token = localStorage.getItem("token");
    setLoading(true);
    try {
      const response = await fetch(`${var_api}invoicebilling/admin/get/invoice/${hospital_id}`, {
        headers: {
          "Content-Type": "application/json",
          Authorization: token,
        },
      });
      if (!response.ok) throw new Error("Failed to fetch data");
      const result = await response.json();
      setData(result || []);
      setFilteredData(result || []); // Set initial filtered data
      setLoading(false);
    } catch (error) {
      console.error("Error fetching data:", error);
      notification.error({
        message: "Fetch Failed",
        description: "Unable to retrieve data. Please try again later.",
      });
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchData();
  },[]);

  // Handle search input change
  const handleSearch = (e) => {
    const value = e.target.value.toLowerCase();
    setSearchTerm(value);
  
    const filtered = data.filter((item) => {
      return (
        (item.invoice_token && item.invoice_token.toLowerCase().includes(value)) ||
        (item.tech_details && item.tech_details.name && item.tech_details.name.toLowerCase().includes(value)) ||
        (item.patient_details && item.patient_details.name && item.patient_details.name.toLowerCase().includes(value)) ||
        (item.appointment_day && item.appointment_day.toLowerCase().includes(value)) ||
        (item.appointment_time && item.appointment_time.toLowerCase().includes(value)) ||
        (item.final_amount && item.final_amount.toString().includes(value)) ||
        (item.paid_amount && item.paid_amount.toString().includes(value)) ||
        (item.balance_amount && item.balance_amount.toString().includes(value)) ||
        (item.paid_status !== undefined && item.paid_status.toString().includes(value))
      );
    });
  
    setFilteredData(filtered);
  };
  
  

  const handlePaginationChange = (page, pageSize) => {
    setCurrentPage(page);
    setPageSize(pageSize);
  };

  const columns = [
    
      {
        title: "Invoice",
        dataIndex: "invoice_token",
        render: (text, record) => (
          <Link
                    to={`/admin/doctor-invoice-report?id=${record.id}`} // Pass token as a query parameter
                    className="text-decoration-none"
                  >
                     {text ? `#INV-${text}` : "N/A"}
                  </Link>
         
        ),
      },      
      {
        title: "Doctor",
        dataIndex: "tech_details",
        render: (text, record) => (
          <div>
            {record.profile_image ? (
              <img src={record.tech_details.profile_image} alt="Profile" style={{ width: 30, height: 30, borderRadius: '50%' }} />
            ) : (
              <span>No Image</span>
            )}
            <span style={{ marginLeft: 10 }}>{record.tech_details.name || "N/A"}</span>
          </div>
        ),
      },
      {
        title: "Patient",
        dataIndex: "patient_details",
        render: (text, record) => (
          <div>
            {record.profile_image ? (
              <img src={record.patient_details.profile_image} alt="Profile" style={{ width: 30, height: 30, borderRadius: '50%' }} />
            ) : (
              <span>No Image</span>
            )}
            <span style={{ marginLeft: 10 }}>{record.patient_details.name || "N/A"}</span>
          </div>
        ),
      },      
    {
      title: "Appointment Date",
      dataIndex: "appointment_day",
      render: (text) => (text ? text : "N/A"),
    },
    {
      title: "Appointment Time",
      dataIndex: "appointment_time",
      render: (text) => (text ? text : "N/A"),
    },
    {
        title: "Final Amount",
        dataIndex: "final_amount",
        render: (text) => (text ? text : "0"),
    },
    // {
    //   title: "Paid Amount",
    //   dataIndex: "paid_amount",
    //   render: (text) => (text ? text : "0"),
    // },
    // {
    //   title: "Balance Amount",
    //   dataIndex: "balance_amount",
    //   render: (text) => (text ? text : "0"),
    // },
    {
      title: "Pay Mode",
      dataIndex: "pay_mode", // New field
      render: (text) => text || 0, 
    },
    {
        title: "Paid Status",
        dataIndex: "paid_status",
        render: (text) => (
          <span
            style={{
              color: text === 1 ? "green" : text === 0 ? "red" : "black",
            }}
          >
            {text === 1 ? "Paid" : text === 0 ? "Not Paid" : "N/A"}
          </span>
        ),
      },
      
      {
        title: "Action",
        dataIndex: "status",
        render: (text, record) => (
          <div className="d-flex justify-content-center align-items-center">
            {/* Always show Pay button */}
            {record.paid_status !== 1 && (
            <Button type="primary" onClick={() => showModal(record)}>
              Pay
            </Button>
              )}
          </div>
        ),
      },
      
    // {
    //   title: "Mobile No",
    //   dataIndex: "mobile_no",
    //   render: (text) => (text ? text : "N/A"),
    // },
    // {
    //   title: "Full Address",
    //   dataIndex: "full_address",
    //   render: (text) => (text ? text : "N/A"),
    // },
    // {
    //   title: "Date of Birth",
    //   dataIndex: "dob",
    //   render: (text) => (text ? text : "N/A"),
    // },
    // {
    //   title: "Gender",
    //   dataIndex: "gender",
    //   render: (text) => (text ? text : "N/A"),
    // },
    // {
    //   title: "Blood Group",
    //   dataIndex: "blood_group",
    //   render: (text) => (text ? text : "N/A"),
    // },
    // {
    //   title: "Action",
    //   render: (_, record) => (
    //     <div className="text-end">
    //       <Button
    //         className="me-1"
    //         type="primary"
    //         onClick={() => handleModalOpen(record)}
    //       >
    //         Edit
    //       </Button>
    //       <Button
    //         type="danger"
    //         onClick={() => handleDeleteConfirm(record.id)}
    //       >
    //         Delete
    //       </Button>
    //     </div>
    //   ),
    // },
  ];


  const handleOk = () => {
    const token = localStorage.getItem('token');
    if (!currentBillingId) {
      console.error("No billing ID selected.");
      return;
    }
  
    if (selectedPaymentModes.length === 0) {
      alert("Please select at least one payment mode.");
      return;
    }
  
    const paymentModesString = selectedPaymentModes.join(", ");
    console.log("Selected Payment Modes:", paymentModesString);
  
     // Create the payload
  const payload = {
    paid_status: 1,
    pay_mode: paymentModesString,
  };


    axios
      .put(`${var_api}invoicebilling/update-status/${currentBillingId.id}`, payload, {
        headers: {
          "Content-Type": "application/json",
          Authorization: token,
        },
      })
      .then((response) => {
        console.log("Payment processed:", response.data);
        fetchData();
  
        // // Update the local billing data
        // const updatedData = billingData.map((billing) =>
        //   billing.id === currentBillingId
        //     ? { ...billing, paid_status: 1,pay_mode: selectedPaymentModes }
        //     : billing
        // );
      
        setIsModalVisible(false);
        setSelectedPaymentModes([])
      })
      .catch((error) => {
        console.error("Error processing payment:", error);
      });
  };


  const handleCancel = () => {
    setIsModalVisible(false);
  };

  const handlePaymentModeChange = (mode, checked) => {
    if (checked) {
      setSelectedPaymentModes([...selectedPaymentModes, mode]);
    } else {
      setSelectedPaymentModes(
        selectedPaymentModes.filter((item) => item !== mode)
      );
    }
  };

  return (
    <>
      <SidebarNav />
      <div className="page-wrapper">
        <div className="content container-fluid">
          <div className="page-header">
            <div className="row">
              <div className="col">
                <h3 className="page-title">Invoice Tables</h3>
                <ul className="breadcrumb">
                  <li className="breadcrumb-item">
                    <Link to="/admin">Dashboard</Link>
                  </li>
                  <li className="breadcrumb-item active">Invoice Tables</li>
                </ul>
              </div>
            </div>
          </div>

          <div className="row mb-3">
            <div className="col-md-4">
              <Input
                placeholder="Search"
                value={searchTerm}
                onChange={handleSearch}
              />
            </div>
          </div>

          <div className="row">
            <div className="col-sm-12">
              <div className="card">
                <div className="card-header">
                  <h4 className="card-title">Invoice Details</h4>
                </div>
                <div className="card-body">
                  <div className="table-responsive">
                    <Table
                     pagination={{
                        total: filteredData.length,
                        pageSize: pageSize, // Limit to 2 rows per page
                        current: currentPage,
                        showSizeChanger: false,
                        onShowSizeChange: (current, size) => handlePaginationChange(current, size),
                        onChange: handlePaginationChange,
                        itemRender: itemRender,
                      }}
                      loading={loading}
                      columns={columns}
                      dataSource={filteredData || []}
                      rowKey={(record) => record?.id}
                    />
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <Modal
        title="Payment Mode"
        visible={isModalVisible}
        onOk={() => handleOk(currentBillingId)}
        onCancel={handleCancel}
      >
        <Form layout="vertical">
          <Form.Item label="Select Payment Mode">
            <Checkbox
              onChange={(e) =>
                handlePaymentModeChange("Cash", e.target.checked)
              }
            >
              Cash
            </Checkbox>
            <Checkbox
              onChange={(e) =>
                handlePaymentModeChange("Online", e.target.checked)
              }
            >
              Online
            </Checkbox>
          </Form.Item>
        </Form>
      </Modal>
    
    </>
  );
};

export default InvoiceList;
